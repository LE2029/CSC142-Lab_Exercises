package MidtermExam;

import java.util.Scanner;

public class CreditCardQualifier {
	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Please enter your annual salary($): ");
		double salary = scanner.nextDouble();
		
		System.out.print("Please enter your credit card rating(1-10): ");
		int creditRating = scanner.nextInt();
		
		if (salary >= 20000 && creditRating >= 7) {
			qualify(); 
		} else {
			noQualify();
		}
		scanner.close(); 
	}
	
	public static void qualify() {
		System.out.println("You qualify for the credit card! ;> ");
		
	}
	
	public static void noQualify() {
		System.out.println("You unfortunatly do not qualify for the credit card... "); 
	}
	
}