package MidtermExam;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class SalesCalculator {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		String filename = getFileName(input);
		
		double totalSales = getTotalSales(filename);
		
		double averageSales = totalSales / 30.0; 
		
		displayResults(totalSales, averageSales);
		
		input.close(); 
		
	}
	
	public static String getFileName(Scanner input) {
		System.out.print("Please enter the filename: ");
		return input.nextLine();
	}
	
	public static double getTotalSales(String filename) {
		double total = 0.0;
		int count = 0;
		
		try {
			File file = new File(filename);
			Scanner fileScanner = new Scanner(file);
			
			while (fileScanner.hasNextDouble() && count < 30) {
				double sales = fileScanner.nextDouble();
				total += sales;
				count++;
			}
			
			fileScanner.close();
			
			if (count < 30) {
				System.out.println("Warning: Only " + count + " sales values found in file. Expected 30 values. :< ");
				
			}
		} catch (FileNotFoundException e) {
			System.out.println("Error: File '" + filename + "' not found.");
			System.out.println("Please check the filename and try again. :< ");
            System.exit(1);
		} catch (Exception e) {
			System.out.println("Error reading file: " + e.getMessage());
            System.exit(1);
		}
		
		return total;
		
	}
	
	public static void displayResults(double total, double average) {
		System.out.println("\n--- Sales Report ---");
		System.out.printf("Total Sales: $%.2f%n", total);
		System.out.printf("Average Sales: $%.2f%n", average); 
	}

}
